/* Terminal IDE — MDS build
 *
 * A professional Minima terminal + full autocomplete, running as a MiniDapp.
 *
 * Autocomplete data is mined at load time from the node's own help pages
 * (help.json — 125 commands incl. the full Maxima classic set). The completion
 * engine is a straight port of the native app's Suggest.java:
 *   "me"                -> commands starting with "me"
 *   "maxima "           -> ONLY maxima's params, required first, unused only
 *   "maxima action:"    -> ONLY the allowed values of action
 *   "maxima action:se"  -> values starting with "se"
 * Quiet on empty input; works inside ; chains and stays silent in quoted strings.
 */
(function () {
  "use strict";

  var KIND_COMMAND = 0, KIND_PARAM = 1, KIND_VALUE = 2;

  // ------------------------------------------------------------------ registry
  // REG: { name -> {name, brief, params:[{name, required, desc, values[]}]} }
  var REG = {};
  var NAMES = []; // command names, help.json order

  var PARAM_RE = /^([a-zA-Z][a-zA-Z0-9]*(?:\|[a-zA-Z0-9]+)*):(\s*\(optional\))?\s*(.*)$/;

  // Parse one help entry ({help, fullhelp}) into {name, brief, params[]}.
  // Shared by the bundled load and the live-help merge so both are identical.
  function parseEntry(name, entry) {
    var brief = (entry.help || "").trim();
    var full = entry.fullhelp || "";
    var cut = full.indexOf("\nExamples:");
    var def = cut >= 0 ? full.slice(0, cut) : full;
    var lines = def.split("\n");

    var params = [];
    var cur = null;

    function flush() {
      if (!cur) return;
      var values = extractValues(cur.descLines);
      var desc = cur.descLines.join(" ").replace(/\s+/g, " ").trim();
      cur.names.forEach(function (n) {
        for (var i = 0; i < params.length; i++) if (params[i].name === n) return; // de-dupe
        params.push({ name: n, required: cur.required, desc: desc, values: values });
      });
      cur = null;
    }

    for (var li = 0; li < lines.length; li++) {
      var raw = lines[li].replace(/\s+$/, "");
      var indented = /^\s/.test(raw);
      var m = PARAM_RE.exec(raw);
      if (m && !indented) {
        flush();
        cur = { names: m[1].split("|"), required: !m[2], descLines: [] };
        if (m[3]) cur.descLines.push(m[3]);
      } else if (cur) {
        if (raw.trim() === "") flush();
        else cur.descLines.push(raw.trim());
      }
    }
    flush();
    return { name: name, brief: brief, params: params };
  }

  function buildRegistry(help) {
    Object.keys(help).forEach(function (name) {
      REG[name] = parseEntry(name, help[name] || {});
      NAMES.push(name);
    });
  }

  // Mine legal values from a param's description block.
  function extractValues(descLines) {
    var vals = [];
    for (var i = 0; i < descLines.length; i++) {
      // "list : List your ..."  /  "info : Show ..."   (word, colon+space, text)
      var mm = /^([a-zA-Z][a-zA-Z0-9]+)\s*:\s+\S/.exec(descLines[i]);
      if (mm) vals.push(mm[1]);
    }
    if (vals.length) return uniq(vals);
    var joined = descLines.join(" ").toLowerCase();
    if (/true or false/.test(joined)) return ["true", "false"];
    if (/true only/.test(joined)) return ["true"];
    if (/asc or desc|ascending or dec/.test(joined)) return ["asc", "desc"];
    if (/\bhex\b.*\bmx\b|from<|to<hex/.test(joined)) return [];
    return [];
  }

  function uniq(a) {
    var seen = {}, out = [];
    for (var i = 0; i < a.length; i++) if (!seen[a[i]]) { seen[a[i]] = 1; out.push(a[i]); }
    return out;
  }

  function usageLine(cmd) {
    if (!cmd.params.length) return cmd.name;
    var s = cmd.name;
    for (var i = 0; i < cmd.params.length; i++) {
      var p = cmd.params[i];
      s += "  " + p.name + ":";
      if (p.values.length) s += p.values.join("|");
    }
    return s;
  }

  // ------------------------------------------------------------------- suggest
  // Port of Suggest.suggest(text, caret). Returns {items, paramHint}.
  function suggest(text, caret) {
    var r = { items: [], paramHint: null };
    if (caret < 0 || caret > text.length) caret = text.length;
    var upto = text.slice(0, caret);

    var segStart = upto.lastIndexOf(";") + 1;
    var seg = upto.slice(segStart);

    // inside an unclosed quoted string: free text, no completion
    var quotes = 0;
    for (var i = 0; i < seg.length; i++) if (seg.charAt(i) === '"') quotes++;
    if (quotes & 1) return r;

    var lead = 0;
    while (lead < seg.length && seg.charAt(lead) === " ") lead++;
    var body = seg.slice(lead);

    var firstSpace = body.indexOf(" ");
    if (firstSpace < 0) {
      // typing the command name itself
      var exact = REG[body];
      if (exact) {
        r.paramHint = usageLine(exact);
        addParamItems(r, exact, seg, "", caret, " ");
      }
      if (body.length) {
        var tokStart = segStart + lead;
        var prefix = [], contains = [];
        for (var n = 0; n < NAMES.length; n++) {
          var c = REG[NAMES[n]];
          if (c.name === body) continue;
          if (c.name.indexOf(body) === 0)
            prefix.push(item(c.name, tokStart, c.name + " ", c.brief, false, KIND_COMMAND));
          else if (c.name.indexOf(body) >= 0)
            contains.push(item(c.name, tokStart, c.name + " ", c.brief, false, KIND_COMMAND));
        }
        r.items = r.items.concat(prefix, contains);
      }
      return r;
    }

    var cmdName = body.slice(0, firstSpace);
    var cmd = REG[cmdName];
    if (!cmd) return r;
    r.paramHint = usageLine(cmd);

    var lastSpace = seg.lastIndexOf(" ");
    var token = seg.slice(lastSpace + 1);
    var tokStart2 = segStart + lastSpace + 1;

    var colon = token.indexOf(":");
    if (colon >= 0) {
      var key = token.slice(0, colon);
      var partial = token.slice(colon + 1);
      var helpCmd = cmd.name === "help" && key === "command";
      var values = valuesFor(cmd, key);
      for (var v = 0; v < values.length; v++) {
        if (values[v].indexOf(partial) !== 0) continue;
        var desc = helpCmd && REG[values[v]] ? REG[values[v]].brief : "";
        r.items.push(item(values[v], tokStart2, key + ":" + values[v] + " ", desc, false, KIND_VALUE));
      }
    } else {
      addParamItems(r, cmd, seg, token, tokStart2, "");
    }
    return r;
  }

  function addParamItems(r, cmd, seg, token, tokStart, prefix) {
    var required = [], optional = [];
    for (var i = 0; i < cmd.params.length; i++) {
      var p = cmd.params[i];
      if (p.name.indexOf(token) !== 0) continue;
      if (seg.indexOf(" " + p.name + ":") >= 0) continue; // already used in this segment
      var desc = p.desc;
      if (!desc && p.values.length) desc = p.values.join(" | ");
      var it = item(p.name + ":", tokStart, prefix + p.name + ":", desc, p.required, KIND_PARAM);
      if (p.required) required.push(it); else optional.push(it);
    }
    r.items = r.items.concat(required, optional);
  }

  function valuesFor(cmd, key) {
    if (cmd.name === "help" && key === "command") return NAMES.slice();
    for (var i = 0; i < cmd.params.length; i++) if (cmd.params[i].name === key) return cmd.params[i].values;
    return [];
  }

  function item(label, tokenStart, insert, desc, required, kind) {
    return { label: label, tokenStart: tokenStart, insert: insert, desc: desc || "", required: !!required, kind: kind };
  }

  function applyItem(text, caret, it) {
    if (caret < 0 || caret > text.length) caret = text.length;
    var start = Math.min(it.tokenStart, caret);
    return { text: text.slice(0, start) + it.insert + text.slice(caret), caret: start + it.insert.length };
  }

  // ----------------------------------------------------- node-killer warnings
  // Port of CommandRegistry.dangerWarning — reply >~1MB over the MDS bridge is
  // still expensive and can hammer the node. Warn before running.
  function dangerWarning(full) {
    var parts = full.split(";");
    for (var i = 0; i < parts.length; i++) {
      var w = dangerSingle(parts[i].trim());
      if (w) return w;
    }
    return null;
  }
  function dangerSingle(cmd) {
    if (!cmd) return null;
    var name = cmd.split(" ")[0];
    if (name === "coins") {
      var bounded = /(^|\s)(depth:|coinid:|relevant:true|sendable:true)/.test(cmd);
      if (!bounded) return "Unbounded 'coins' can build a giant reply. Add depth: (start small, e.g. depth:4) or relevant:true.";
    }
    if (name === "history") {
      var m = /max:(\d+)/.exec(cmd);
      var max = m ? parseInt(m[1], 10) : -1;
      if (max < 0 || max > 25) return "'history' returns full TxPoW bodies (~14KB each). Use max:8 or less and page with offset:.";
    }
    if (name === "printtree" && cmd.indexOf("depth:") < 0)
      return "'printtree' without depth: can return a huge tree. Add depth: (e.g. depth:10).";
    if (name === "printmmr") return "'printmmr' can return a very large reply. Run only if you need it.";
    return null;
  }

  // ------------------------------------------------------------------- UI wire
  var $ = function (id) { return document.getElementById(id); };
  var elCmd, elSug, elHint, elOut, elScroll, elStatus, elBlock;
  var sgItems = [], sgActive = -1;
  var history = loadHistory(), histIdx = history.length;

  function boot() {
    elCmd = $("cmd"); elSug = $("suggest"); elHint = $("paramhint");
    elOut = $("output"); elScroll = $("scroll"); elStatus = $("status"); elBlock = $("block");

    $("run").addEventListener("click", runCurrent);
    elCmd.addEventListener("input", refreshSuggest);
    elCmd.addEventListener("keydown", onKey);
    elCmd.addEventListener("click", refreshSuggest);
    document.addEventListener("click", function (e) {
      if (!elSug.contains(e.target) && e.target !== elCmd) hideSuggest();
    });
    elCmd.focus();
    sysLine("Terminal IDE ready. " + NAMES.length + " commands loaded (Maxima classic set included). Type to autocomplete · Tab to accept · Enter to run.");
  }

  function refreshSuggest() {
    var res = suggest(elCmd.value, elCmd.selectionStart);
    renderSuggest(res);
  }

  function renderSuggest(res) {
    if (res.paramHint) { elHint.textContent = res.paramHint; elHint.classList.remove("hidden"); }
    else elHint.classList.add("hidden");

    sgItems = res.items || [];
    elSug.innerHTML = "";
    if (!sgItems.length) { hideSuggest(); return; }

    sgActive = 0;
    var kindCls = ["k-cmd", "k-param", "k-value"];
    sgItems.forEach(function (it, idx) {
      var row = document.createElement("div");
      row.className = "sg-item " + kindCls[it.kind] + (idx === 0 ? " active" : "");
      var lab = document.createElement("span");
      lab.className = "sg-label";
      lab.textContent = it.label;
      if (it.required) { var rq = document.createElement("span"); rq.className = "sg-req"; rq.textContent = "req"; lab.appendChild(rq); }
      var desc = document.createElement("span");
      desc.className = "sg-desc"; desc.textContent = it.desc || "";
      row.appendChild(lab); row.appendChild(desc);
      row.addEventListener("mousedown", function (e) { e.preventDefault(); accept(idx); });
      elSug.appendChild(row);
    });
    elSug.classList.remove("hidden");
  }

  function hideSuggest() { elSug.classList.add("hidden"); elSug.innerHTML = ""; sgItems = []; sgActive = -1; }

  function setActive(i) {
    var rows = elSug.children;
    if (!rows.length) return;
    if (i < 0) i = rows.length - 1;
    if (i >= rows.length) i = 0;
    if (sgActive >= 0 && rows[sgActive]) rows[sgActive].classList.remove("active");
    sgActive = i; rows[i].classList.add("active");
    rows[i].scrollIntoView({ block: "nearest" });
  }

  function accept(i) {
    if (i == null) i = sgActive;
    if (i < 0 || i >= sgItems.length) return;
    var out = applyItem(elCmd.value, elCmd.selectionStart, sgItems[i]);
    elCmd.value = out.text;
    elCmd.setSelectionRange(out.caret, out.caret);
    elCmd.focus();
    refreshSuggest();
  }

  function onKey(e) {
    var open = !elSug.classList.contains("hidden") && sgItems.length;
    if (open) {
      if (e.key === "ArrowDown") { e.preventDefault(); setActive(sgActive + 1); return; }
      if (e.key === "ArrowUp")   { e.preventDefault(); setActive(sgActive - 1); return; }
      if (e.key === "Tab")       { e.preventDefault(); accept(); return; }
      if (e.key === "Enter")     { e.preventDefault(); accept(); return; }
      if (e.key === "Escape")    { e.preventDefault(); hideSuggest(); return; }
    } else {
      if (e.key === "ArrowUp")   { e.preventDefault(); histPrev(); return; }
      if (e.key === "ArrowDown") { e.preventDefault(); histNext(); return; }
      if (e.key === "Enter")     { e.preventDefault(); runCurrent(); return; }
      if (e.key === "Tab")       { e.preventDefault(); refreshSuggest(); return; }
    }
  }

  // --------------------------------------------------------------- run command
  function runCurrent() {
    var raw = elCmd.value.trim();
    if (!raw) return;
    hideSuggest();
    var warn = dangerWarning(raw);
    if (warn && !window.confirm(warn + "\n\nRun anyway?")) return;
    pushHistory(raw);
    elCmd.value = "";
    elHint.classList.add("hidden");
    execute(raw);
  }

  function execute(cmd) {
    var entry = document.createElement("div");
    entry.className = "entry";
    var line = document.createElement("div");
    line.className = "cmdline";
    line.textContent = cmd;
    line.title = "Click to edit / re-run";
    line.addEventListener("click", function () { elCmd.value = cmd; elCmd.focus(); refreshSuggest(); });
    entry.appendChild(line);
    elOut.appendChild(entry);
    scrollDown();

    MDS.cmd(cmd, function (res) {
      var isErr = !!(res && (res.status === false || res.error));
      entry.classList.add(isErr ? "err" : "ok");
      var pre = document.createElement("pre");
      pre.className = "result" + (isErr ? " iserr" : "");
      pre.innerHTML = renderJSON(res);
      entry.appendChild(pre);
      scrollDown();
    });
  }

  function scrollDown() { elScroll.scrollTop = elScroll.scrollHeight; }

  function sysLine(txt, warn) {
    var d = document.createElement("div");
    d.className = "sys" + (warn ? " warn" : "");
    d.textContent = txt;
    elOut.appendChild(d);
    scrollDown();
  }

  // ---------------------------------------------------------- JSON highlighter
  function esc(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }

  function renderJSON(obj) {
    var json;
    try { json = JSON.stringify(obj, null, 2); }
    catch (e) { return esc(String(obj)); }
    if (json === undefined) return esc(String(obj));
    // tokenizer: strings (incl. keys), literals, numbers
    var re = /("(\\.|[^"\\])*")(\s*:)?|\b(true|false)\b|\bnull\b|-?\d+(\.\d+)?([eE][+-]?\d+)?/g;
    return json.replace(re, function (m, str, _c, isKey, boolLit) {
      if (str !== undefined) {
        if (isKey) return '<span class="j-key">' + esc(str) + '</span>' + isKey;
        var lower = str.toLowerCase();
        var cls = /error|invalid|fail/.test(lower) ? "j-err" : "j-str";
        return '<span class="' + cls + '">' + esc(str) + '</span>';
      }
      if (boolLit !== undefined) {
        var isFalse = boolLit === "false";
        return '<span class="' + (isFalse ? "j-err" : "j-bool") + '">' + boolLit + '</span>';
      }
      if (m === "null") return '<span class="j-null">null</span>';
      return '<span class="j-num">' + m + '</span>';
    });
  }

  // ------------------------------------------------------------------- history
  function loadHistory() {
    try { return JSON.parse(localStorage.getItem("tide_history") || "[]"); }
    catch (e) { return []; }
  }
  function pushHistory(cmd) {
    if (history[history.length - 1] !== cmd) history.push(cmd);
    if (history.length > 300) history = history.slice(-300);
    histIdx = history.length;
    try { localStorage.setItem("tide_history", JSON.stringify(history)); } catch (e) {}
  }
  function histPrev() {
    if (!history.length) return;
    if (histIdx > 0) histIdx--;
    elCmd.value = history[histIdx] || "";
    var n = elCmd.value.length; elCmd.setSelectionRange(n, n);
  }
  function histNext() {
    if (!history.length) return;
    if (histIdx < history.length) histIdx++;
    elCmd.value = histIdx >= history.length ? "" : history[histIdx];
    var n = elCmd.value.length; elCmd.setSelectionRange(n, n);
  }

  // ------------------------------------------------------------ status / block
  function setStatus(cls, txt) { elStatus.className = cls; elStatus.textContent = txt; }
  function refreshBlock() {
    MDS.cmd("block", function (res) {
      if (res && res.status && res.response != null) {
        var b = res.response.block != null ? res.response.block : res.response;
        elBlock.textContent = "block " + b;
      }
    });
  }

  // ---------------------------------------------------------------- MDS init
  function loadHelp(cb) {
    // help.json ships in the web root — fetch relative.
    var x = new XMLHttpRequest();
    x.open("GET", "help.json", true);
    x.onreadystatechange = function () {
      if (x.readyState === 4) {
        try { cb(JSON.parse(x.responseText)); }
        catch (e) { cb(null, e); }
      }
    };
    x.send();
  }

  MDS.init(function (msg) {
    if (msg.event === "inited") {
      loadHelp(function (help, err) {
        if (!help) {
          document.addEventListener("DOMContentLoaded", function () {
            boot(); setStatus("err", "help.json failed");
            sysLine("Could not load help.json — autocomplete disabled: " + err, true);
          });
          return;
        }
        buildRegistry(help);
        if (document.readyState === "loading")
          document.addEventListener("DOMContentLoaded", function () { boot(); afterBoot(); });
        else { boot(); afterBoot(); }
      });
    } else if (msg.event === "NEWBLOCK") {
      if (elBlock) refreshBlock();
    }
  });

  function afterBoot() {
    setStatus("ok", "connected");
    refreshBlock();
    mergeLiveHelp();
  }

  // ------------------------------------------------------- live help merge
  // Reconcile the bundled registry with the running node's actual command set.
  // `help` (no arg) returns { "<name padded>": "<brief>" }. That list is CURATED
  // by the node (it omits maxima/mds/etc.), so it is NOT authoritative for what
  // exists — we therefore only ADD commands it lists that we don't bundle, and
  // refresh briefs for ones we do. We never remove: a name missing from the
  // curated list may still be a real command (that's exactly the Maxima case).
  function mergeLiveHelp() {
    MDS.cmd("help", function (res) {
      if (!res || !res.status || !res.response || typeof res.response !== "object") return;
      var live = res.response;
      var missing = [];
      Object.keys(live).forEach(function (padded) {
        var name = String(padded).trim();
        if (!name) return;
        var brief = String(live[padded] || "").trim();
        if (REG[name]) {
          if (brief) REG[name].brief = brief; // keep briefs exact to this node build
        } else {
          missing.push(name);
        }
      });
      if (!missing.length) { refreshSuggest(); return; }
      fetchDetails(missing, 0, function (added) {
        if (added.length) sysLine("Live help merge: added " + added.length +
          " node command" + (added.length === 1 ? "" : "s") + " — " + added.join(", "));
        refreshSuggest();
      });
    });
  }

  // Fetch full help for unknown commands one at a time (usually zero of them).
  function fetchDetails(names, i, done) {
    if (i >= names.length) { done(fetchDetails._added || (fetchDetails._added = [])); fetchDetails._added = []; return; }
    var name = names[i];
    MDS.cmd("help command:" + name, function (res) {
      if (res && res.status && res.response && res.response.fullhelp !== undefined) {
        REG[name] = parseEntry(name, { help: res.response.help, fullhelp: res.response.fullhelp });
        NAMES.push(name);
        (fetchDetails._added || (fetchDetails._added = [])).push(name);
      }
      fetchDetails(names, i + 1, done);
    });
  }
})();
